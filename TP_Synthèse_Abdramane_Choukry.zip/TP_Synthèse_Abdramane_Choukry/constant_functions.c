#include "constant_functions.h"

// Définition des constantes
const char welcom_msg[] = "Bienvenue dans le Shell ENSEA. Pour quitter, tapez 'exit'.";
const char prompt[] = "enseash %";

