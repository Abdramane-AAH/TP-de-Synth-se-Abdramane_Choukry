#ifndef CONSTANT_FUNCTIONS_H
#define CONSTANT_FUNCTIONS_H

// Déclaration des constantes comme des chaînes de caractères constantes
extern const char welcom_msg[];
extern const char prompt[];

#endif // CONSTANT_FUNCTIONS_H
