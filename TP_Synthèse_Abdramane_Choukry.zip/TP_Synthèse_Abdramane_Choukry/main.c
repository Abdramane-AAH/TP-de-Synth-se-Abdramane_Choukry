#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <math.h>
#include "constant_functions.h"

#define BUFSIZE 1096
int argc;
ssize_t commande_size; // Correction du type pour correspondre à la sortie de read
char **list_cmd;       // Correction pour définir un pointeur de tableau de chaînes

void exeCommande(char **buf, ssize_t commande_size);
char **separeCommande(char *cmd);

int main()
{
    char buf[BUFSIZE] = welcom_msg;
    write(1, buf, strlen(buf));
    while (1)
    { // Lecture des commandes
        write(1, "% ", strlen("% "));
        memset(buf, 0, BUFSIZE); // clear buffer
        argc = 0;
        if ((commande_size = read(0, buf, BUFSIZE)) == -1)
        {
            perror("read");
            exit(EXIT_FAILURE);
        }
        list_cmd = separeCommande(buf);
        exeCommande(list_cmd, commande_size);
    }
}
void exeCommande(char **buf, ssize_t commande_size)
{
    char msg_out[BUFSIZE] = "enseash [";

    if (strcmp("exit", buf[0]) == 0 || commande_size == 0)
    {
        write(1, "Bye bye...\n", strlen("Bye bye...\n"));
        exit(EXIT_FAILURE);
    }



    char **separeCommande(char *cmd)
    {
        char **argv;
        argv = malloc(20 * sizeof(char *));
        int i = 0;
        char *tmp = strtok(cmd, " ");

        while (tmp != NULL)
        {
            argv[i] = malloc(20);
            strcpy(argv[i], tmp);
            tmp = strtok(NULL, " ");
            i++;
        }
        argv[i - 1][strlen(argv[i - 1]) - 1] = '\0'; // supprime le cracatere enter sur le dernier arg
        argc = i;
        return argv;
    }
}